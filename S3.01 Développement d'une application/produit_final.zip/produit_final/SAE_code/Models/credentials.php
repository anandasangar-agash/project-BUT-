<?php 

$dsn = 'pgsql:host=;dbname=';
$login = '';
$mdp = '';

?>
