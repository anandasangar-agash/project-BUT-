<div class="container-fluid">
	<footer class="py-0 my-0">
		<ul class="nav justify-content-center or-primaire-border pb-3 mb-3">
			<li class="nav-item">
				<a href="?controller=accueil&action=accueil" class="nav-link px-2 text-white">Accueil</a>
			</li>
			<li class="nav-item">
				<a href="?controller=annuaire&action=annuaire" class="nav-link px-2 text-white">Annuaire</a>
			</li>
			<li class="nav-item">
				<a href="?controller=assistance&action=assistance" class="nav-link px-2 text-white">Assistance</a>
			</li>
		</ul>
			<p class="text-center text_footer_bas">&copy; 2024 Di Evoluzion, Inc</p>
	</footer>
</div>
</body>
</html>
